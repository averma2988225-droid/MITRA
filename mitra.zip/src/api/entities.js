import { base44 } from './base44Client';


export const MonitoringData = base44.entities.MonitoringData;

export const ChatMessage = base44.entities.ChatMessage;

export const Alert = base44.entities.Alert;



// auth sdk:
export const User = base44.auth;